#include "MPC.h"

int main(int argc, char** argv)
{
    //初始化ROS节点，节点名称请使用与ROS包名相同
    ros::init(argc, argv, "MPC_controller");
    //定义类对象指针
    ros::NodeHandle nh;
    double loopHz = 50;
    MPCtrack::Controller *exe = new MPCtrack::Controller(nh, loopHz);
    //PureTrack::Controller *exe = new PureTrack::Controller(nh, loopHz);
    //调用对象run函数，外部直接调用的类应当包含至少一个run函数
    exe->run();
    //关闭ROS节点
    ros::shutdown();
    return 0;
}